---
title: "To Kill a Mockingbird"
author: "Harper Lee"
price: "$8.99"
description: "A novel about racial injustice in the Deep South."
img: "/_data/pictures/mockingbird.jpg"
---
