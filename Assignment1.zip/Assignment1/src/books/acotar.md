---
title: "A Court of Thorns and Roses"
author: "Sarah J. Maas"
price: "$20.00"
description: "A fantasy novel about about a young huntress named Feyre who is taken to a magical fae realm after killing a wolf, where she uncovers dark secrets and embarks on a journey of love, danger, and self-discovery."
img: "/_data/pictures/acotar.jpg"
---

