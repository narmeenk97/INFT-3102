---
title: "The Great Gatsby"
author: "F. Scott Fitzgerald"
price: "$10.99"
description: "A classic novel set in the Jazz Age."
img: "/_data/pictures/TGG.jpg"
---

