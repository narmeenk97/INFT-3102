---
title: "A Court of Mist and Fury"
author: "Sarah J. Maas"
price: "$20.00"
description: "A Court of Mist and Fury follows Feyre as she navigates the aftermath of her trials Under the Mountain, forging new alliances and confronting her inner strength while entangled in the looming war between mortal and fae realms, and her growing bond with the enigmatic High Lord, Rhysand."
img: "/_data/pictures/acomaf.jpg"
---

